#include "servo_motor_pid.h"
#include <math.h>
#include "timer.h"


 extern Servo_motor servo_motor_x;
 extern Servo_motor servo_motor_y;
 extern u8 mubiao[9][2];
 
   

	//y��   1160    ���  1360   gao  960
//x��   1100              980    1300

//  2   0.02   30
void servo_motor_Init(void)
{
  servo_motor_x.SetValue=0;
	servo_motor_x.BackValue=0;
	servo_motor_x.servo_middle=1100;
  servo_motor_x.Kp=2;//1.5
	servo_motor_x.flag1=0;
	servo_motor_x.flag2=0;
	servo_motor_x.flag3=0;
	servo_motor_x.flag4=0;
	servo_motor_x.zhixing1=0;
		servo_motor_x.zhixing2=0;
		servo_motor_x.zhixing3=0;
		servo_motor_x.zhixing4=0;
		servo_motor_x.zhixing5=0;
	servo_motor_x.Ki=0.12;
	servo_motor_x.SumError_limit=2000;
	servo_motor_x.Kd=30;//30
	servo_motor_x.Error=0;
	servo_motor_x.LastError=0;
	servo_motor_x.PreError=0;
	servo_motor_x.SumError=0;
	servo_motor_x.PWMOut=0;
	
	
	
	servo_motor_y.SetValue=0;
	servo_motor_y.BackValue=0;
	servo_motor_y.servo_middle=1160;
  servo_motor_y.Kp=2;//2
	servo_motor_y.Ki=0.12;
	servo_motor_y.Kd=30;//30
	servo_motor_y.flag1=0;
	servo_motor_y.flag2=0;
	servo_motor_y.flag3=0;
	servo_motor_y.flag4=0;
	servo_motor_y.zhixing1=0;
		servo_motor_y.zhixing2=0;
		servo_motor_y.zhixing3=0;
		servo_motor_y.zhixing4=0;
		servo_motor_y.zhixing5=0;
	servo_motor_y.Error=0;
	servo_motor_y.LastError=0;
	servo_motor_y.PreError=0;
	servo_motor_y.SumError=0;
	servo_motor_y.PWMOut=0;

}

int  Servo_motor_Control_X(Servo_motor *V)
{
   #define FLAG  0
    int Error,LastError,PreError;
	//���� ����ʽPID
	  Error = V->SetValue - V->BackValue;//e(k) KI

    	if(V->zhixing1==1)
			{
			 if(Error<50&&Error>-50)
	   	{
		   Error=0;
		   }
			}
			else
			{
	    if(Error<7&&Error>-7)
	  	{
		    Error=0;
		
		   }
    	}
	  LastError = Error- V->LastError ; //e(k)-e(k-1)  KP
    PreError = LastError - V->PreError;//[e(k)-e(k-1)]-[e[k-1]-e(k-2)] kd
    V->LastError=	Error;
	  V->PreError= LastError;
	  
	
	//����λ��ʽPID
	  V->SumError=V->SumError+Error;
		
		
			 	 if(V->SumError>V->SumError_limit)
		{
		  V->SumError=V->SumError_limit;
		}

    if(V->SumError<(0-V->SumError_limit))	
		{
		 V->SumError=0-V->SumError_limit;
		}	
	
	//������
//	  if(V->SumError>=2000)
//		{
//		  V->SumError=2000;
//		}

//    if(V->SumError<-2000)	
//		{
//		 V->SumError=-2000;
//		}			
		
//		 if(V->SumError>=500)
//		{
//		  V->SumError=500;
//		}

//    if(V->SumError<-500)	
//		{
//		 V->SumError=-500;
//		}	
//	   if(FLAG)
//   	{
//	    
//			
//			V->PWMOut+=V->Kp*LastError+V->Ki*Error+V->Kd*PreError;
//	   }   
//		else
//		{
//			if(Error>=0)
//			{
//				if(Error<40)
//					 V->Kp=0.001*Error*Error*Error;
//		     else	if(Error<80&&Error>=40)
//			    V->Kp=0.001*Error*Error;
//			   else if(160>Error&&Error>=80)
//				   V->Kp=0.01*Error;
//			    else
//					  V->Kp=1;
//		  }
//			else 
//			{
//			  if(Error>-40)
//					 V->Kp=-0.001*Error*Error*Error;
//		  	if(Error>-80&&Error<=-40)
//			    V->Kp=0.001*Error*Error;
//			   else if(Error>-160&&Error<=-80)
//				   V->Kp=-0.01*Error;
//			    else
//					  V->Kp=1;
//			}


//if(Error>0)
//{
//if(Error<10)
//	{
//	 V->Kp=1+Error*Error*Error*0.00000027;
//	}

// else if( Error>=10&&Error<60)
//	{
//	 V->Kp=Error*Error*0.00009+1.3;
//	}

//  else if(Error>60&&Error<120)//1.78
//	{
//	 V->Kp=1.6+Error*0.003;
//	
//	}
//  else 
//	{
//	  V->Kp=2; 
//	
//	}
//}
//else
//{
//    if(Error>-10)
//	{
//	 V->Kp=1-Error*Error*Error*0.00000027;
//	}

// else if( Error<=-10&&Error>-60)
//	{
//	 V->Kp=Error*Error*0.00009+1.3;
//	}

//  else if(Error<=-60&&Error>-120)//1.78
//	{
//	 V->Kp=1.6-Error*0.003;
//	
//	}
//  else 
//	{
//	  V->Kp=2; 
//	
//	}
//}
//if(((Error<35)&&(Error>10))||((Error>-35)&&(Error<-10)))
//		 {
//		   V->Kp=8;
//		 }
//		 else if((Error>-10)&&(Error<10))
//		 {
//		    V->Kp=0;
//		 }
//		 else
//		 {
//		   V->Kp=2.3;
//		 
//		 }



//////  if(Error>30&&Error<-30)
//////	{
//////	  V->Ki=0.2;
//////	
//////	}
//////	else
//////	{
//////	  V->Ki=0.3;
//////	
//////	}
 if(Error==0)
	 {
	  V->PWMOut=0;
		 if(V->zhixing3==1)
		 {
		   V->flag2= V->flag2+1;
		 }
		 if(V->zhixing5==1)
		 {
		   V->flag5= V->flag5+1;
		 }
	 
	 }

		 else
		 {
			 
			 
			  if( V->flag1)
			{
       if(Error>30&&Error<-30)
	      {
	       V->Ki=0.2;
	
       	}
  	     else
	     {
	       V->Ki=0.22;
	
	     }
		}
		  V->PWMOut=V->Kp*Error+V->Ki*V->SumError+V->Kd*LastError;
//		}
		 }
		
		V->PWMOut=V->servo_middle- V->PWMOut;
		 if(V->PWMOut>1300)
	  V->PWMOut=1300;
		if(V->PWMOut<980)
	    V->PWMOut=980;
	
	
	

	return (int)(V->PWMOut);
}


int  Servo_motor_Control_Y(Servo_motor *V)
{
   #define FLAG  0
    int Error,LastError,PreError;
	//���� ����ʽPID
	  Error = V->SetValue - V->BackValue;//e(k) KI
if(V->zhixing1==1)
			{
			 if(Error<50&&Error>-50)
	   	{
		   Error=0;
		   }
			}
			else
			{
	    if(Error<7&&Error>-7)
	  	{
		    Error=0;
		
		   }
    	}
	  LastError = Error- V->LastError ; //e(k)-e(k-1)  KP
    PreError = LastError - V->PreError;//[e(k)-e(k-1)]-[e[k-1]-e(k-2)] kd
    V->LastError=	Error;
	  V->PreError= LastError;
	  
	
	//����λ��ʽPID
	  V->SumError=V->SumError+Error;
	
	//������
//	  if(V->SumError>=2000)
//		{
//		  V->SumError=2000;
//		}

//    if(V->SumError<-2000)	
//		{
//		 V->SumError=-2000;
//		}		

	 	 if(V->SumError>V->SumError_limit)
		{
		  V->SumError=V->SumError_limit;
		}

    if(V->SumError<(0-V->SumError_limit))	
		{
		 V->SumError=0-V->SumError_limit;
		}		
//	   if(FLAG)
//   	{
//	    
//			
//			V->PWMOut+=V->Kp*LastError+V->Ki*Error+V->Kd*PreError;
//	   }   
//		else
//		{
//			if(Error>=0)
//			{
////				if(Error<30)
//					 V->Kp=0.001*Error*Error*Error;
//		     else	if(Error<60&&Error>=30)
//			    V->Kp=0.001*Error*Error;
//			   else if(120>Error&&Error>=60)
//				   V->Kp=0.01*Error;
//			    else
//					  V->Kp=1;
//		  }
//			else 
//			{
//			  if(Error>-30)
//					 V->Kp=-0.001*Error*Error*Error;
//		  	if(Error>-60&&Error<=-30)
//			    V->Kp=0.001*Error*Error;
//			   else if(Error>-120&&Error<=-60)
//				   V->Kp=-0.01*Error;
//			    else
//					  V->Kp=1;
//			}
//if(Error>0)
//{
//if(Error<10)
//	{
//	 V->Kp=1+Error*Error*Error*0.00000027;
//	}

// else if( Error>=10&&Error<60)
//	{
//	 V->Kp=Error*Error*0.00009+1.3;
//	}

//  else if(Error>60&&Error<120)//1.78
//	{
//	 V->Kp=1.6+Error*0.003;
//	
//	}
//  else 
//	{
//	  V->Kp=2; 
//	
//	}
//}
//else
//{
//    if(Error>-10)
//	{
//	 V->Kp=1-Error*Error*Error*0.00000027;
//	}

// else if( Error<=-10&&Error>-60)
//	{
//	 V->Kp=Error*Error*0.00009+1.3;
//	}

//  else if(Error<=-60&&Error>-120)//1.78
//	{
//	 V->Kp=1.6-Error*0.003;
//	
//	}
//  else 
//	{
//	  V->Kp=2; 
//	
//	}
//}

//}

//  if( V->flag1)
//	{
//     if(((Error<35)&&(Error>5))||((Error>-35)&&(Error<-5)))
//		 {
//		   V->Kp=4;
//		 }
//		 else if((Error>-5)&&(Error<5))
//		 {
//		    V->Kp=0;
//		 }
//		 else
//		 {
//		   V->Kp=2.5;
//		 }

//	 }
   if(Error==0)
	 {
	  V->PWMOut=0;
		 if(V->zhixing3==1)
		 {
		   V->flag2= V->flag2+1;
		 }
		  if(V->zhixing5==1)
			{
			 V->flag5= V->flag5+1;
			}
	 
	 }
	 else
	 {
		  if( V->flag1)
			{
       if(Error>30&&Error<-30)
	      {
	       V->Ki=0.2;
	
       	}
  	     else
	     {
	       V->Ki=0.22;
	
	     }
		}
		
		  V->PWMOut=V->Kp*Error+V->Ki*V->SumError+V->Kd*LastError;
//}
		}
    V->PWMOut=  V->PWMOut+ V->servo_middle;
			 if(V->PWMOut>1360)
	  V->PWMOut=1360;
		if(V->PWMOut<920)
	    V->PWMOut=920;
	 if(V->zhixing3==1)
	 {
	   if(V->BackValue<10&&V->BackValue>-10)
	    V->PWMOut=920;
	 }

	return (int)(V->PWMOut);
}

void mode_zero(void)
{
  servo_motor_x.Kp=2;//2
	servo_motor_x.Ki=0.02;
	servo_motor_x.Kd=30;//30
	servo_motor_x.SumError_limit=500;
	servo_motor_x.flag1=0;
	servo_motor_x.zhixing1=1;
	
	
	servo_motor_y.Kp=2;
	servo_motor_y.Ki=0.02;
	servo_motor_y.Kd=30;
	servo_motor_y.SumError_limit=500;
	servo_motor_y.flag1=1;
	servo_motor_y.zhixing1=1;
	servo_motor_x.SetValue=mubiao[7][0];
	servo_motor_y.SetValue=mubiao[7][1];
	
//  TIM_SetCompare1(TIM14,servo_motor_x.servo_middle);//y��
//	TIM_SetCompare1(TIM12,servo_motor_y.servo_middle);
//   TIM_SetCompare1(TIM12,	980);//x��  
	
}


void mode_one(void)
{
  servo_motor_x.Kp=2;//2
	servo_motor_x.Ki=0.02;
	servo_motor_x.Kd=30;//30
	servo_motor_x.SumError_limit=2000;
	servo_motor_x.flag1=1;
	
	
	servo_motor_y.Kp=2;
	servo_motor_y.Ki=0.02;
	servo_motor_y.Kd=30;
	servo_motor_y.SumError_limit=2000;
	servo_motor_y.flag1=1;
	servo_motor_x.SetValue=mubiao[4][0];
	servo_motor_y.SetValue=mubiao[4][1];
	
   TIM_SetCompare1(TIM14,1160);//y��
   TIM_SetCompare1(TIM12,1200);//x��  
	
}
void mode_two(void)
{

   servo_motor_x.Kp=2.3;//2.2
	 servo_motor_x.Ki=0.12;
	 servo_motor_x.Kd=35;//30
	 servo_motor_x.SumError_limit=500;
	 servo_motor_x.flag1=0;
	 servo_motor_x.flag2=0;
	 servo_motor_x.zhixing3=1;
	
	 servo_motor_y.Kp=2.3;//2.2
	 servo_motor_y.Ki=0.12;
	 servo_motor_y.Kd=35;//30
	 servo_motor_y.SumError_limit=500;
	 servo_motor_y.flag1=0;
	 servo_motor_y.flag2=0;
	 servo_motor_y.zhixing3=1;
	
	 servo_motor_x.SetValue=mubiao[3][0];
	 servo_motor_y.SetValue=mubiao[3][1];
   TIM_SetCompare1(TIM14,1300);//y��  1300
   TIM_SetCompare1(TIM12,	1300);//x��  1300

}


void mode_two_twoo(void)
{
  servo_motor_x.Kp=2.3;//2
	servo_motor_x.Ki=0.02;
	servo_motor_x.Kd=40;//30
	servo_motor_x.SumError_limit=2000;
	servo_motor_x.flag1=1;
	
	
	servo_motor_y.Kp=2;
	servo_motor_y.Ki=0.02;
	servo_motor_y.Kd=40;
	servo_motor_y.SumError_limit=2000;
	servo_motor_y.flag1=1;
	servo_motor_x.SetValue=mubiao[4][0];
	servo_motor_y.SetValue=mubiao[4][1];
	
   TIM_SetCompare1(TIM14,1260);//y��
   TIM_SetCompare1(TIM12,	980);//x��  
	
	
	
	
	
	

}



void mode_three(void)
{

   servo_motor_x.Kp=2;//2.2
	 servo_motor_x.Ki=0.02;
	 servo_motor_x.Kd=30;
	 servo_motor_x.SumError_limit=2000;
	 servo_motor_x.flag1=0;
	 servo_motor_x.flag2=0;
	 servo_motor_x.flag3=1;
	
	
	 servo_motor_y.Kp=2;//2.2
	 servo_motor_y.Ki=0.02;
	 servo_motor_y.Kd=30;
	 servo_motor_y.SumError_limit=2000;
	 servo_motor_y.flag1=0;
	 servo_motor_y.flag2=0;
	 servo_motor_y.flag3=1;
	
	
	 servo_motor_x.SetValue=mubiao[2][0];
	 servo_motor_y.SetValue=mubiao[2][1];
   TIM_SetCompare1(TIM14,1280);//y��
   TIM_SetCompare1(TIM12,	1100);//x��  

}


void mode_four(void)
{  
	
	 servo_motor_x.Kp=1.5;//2.2
	 servo_motor_x.Ki=0.12;
	 servo_motor_x.Kd=10;
	 servo_motor_x.SumError_limit=500;
	 servo_motor_x.flag1=0;
	 servo_motor_x.flag2=0;
	 servo_motor_x.zhixing3=1;
	
	 servo_motor_y.Kp=1.5;//2.2
	 servo_motor_y.Ki=0.12;
	 servo_motor_y.Kd=10;
	 servo_motor_y.SumError_limit=500;
	 servo_motor_y.flag1=0;
	 servo_motor_y.flag2=0;
	 servo_motor_y.zhixing3=1;
	
	 servo_motor_x.SetValue=110;
	 servo_motor_y.SetValue=110;
   TIM_SetCompare1(TIM14,1160);//y��
   TIM_SetCompare1(TIM12,	1110);//x��  

}

void mode_five(void)
{
   servo_motor_x.Kp=2;//2.2
	 servo_motor_x.Ki=0.02;
	 servo_motor_x.Kd=30;
	 servo_motor_x.SumError_limit=2000;
	 servo_motor_x.flag1=0;
	 servo_motor_x.flag2=0;
	 servo_motor_x.flag3=0;
	 servo_motor_x.zhixing5=1;
	 servo_motor_x.flag5=1;
	
	
	 servo_motor_y.Kp=2;//2.2
	 servo_motor_y.Ki=0.02;
	 servo_motor_y.Kd=30;
	 servo_motor_y.SumError_limit=2000;
	 servo_motor_y.flag1=0;
	 servo_motor_y.flag2=0;
	 servo_motor_y.flag3=0;
   servo_motor_y.zhixing5=1;
	 servo_motor_x.flag5=1;
	
	
	 servo_motor_x.SetValue=mubiao[2][0];
	 servo_motor_y.SetValue=mubiao[2][1];
   TIM_SetCompare1(TIM14,1280);//y��
   TIM_SetCompare1(TIM12,	1100);//x��  

}

void mode_five_one(void)
{
	

	
	
	 servo_motor_x.Kp=2;//2
	servo_motor_x.Ki=0.02;
	servo_motor_x.Kd=50;//30
	servo_motor_x.SumError_limit=2000;
	servo_motor_x.flag1=1;
	
	
	servo_motor_y.Kp=2;
	servo_motor_y.Ki=0.02;
	servo_motor_y.Kd=50;
	servo_motor_y.SumError_limit=2000;
	servo_motor_y.flag1=1;
	servo_motor_x.SetValue=mubiao[4][0];
	servo_motor_y.SetValue=mubiao[4][1];
	
   TIM_SetCompare1(TIM14,1000);//y��
   TIM_SetCompare1(TIM12,960);//x�� 
//	

	
	


}

void mode_five_two(void)
{
	
	
	 servo_motor_x.Kp=2;//2.2
	 servo_motor_x.Ki=0.02;
	 servo_motor_x.Kd=30;
	 servo_motor_x.SumError_limit=2000;
	 servo_motor_x.flag1=0;
	 servo_motor_x.flag2=0;
	 servo_motor_x.flag3=0;
	 servo_motor_x.zhixing5=1;
	 servo_motor_x.flag5=1;
	
	
	 servo_motor_y.Kp=2;//2.2
	 servo_motor_y.Ki=0.02;
	 servo_motor_y.Kd=30;
	 servo_motor_y.SumError_limit=2000;
	 servo_motor_y.flag1=0;
	 servo_motor_y.flag2=0;
	 servo_motor_y.flag3=0;
	 servo_motor_x.flag5=1;
	
	
	 servo_motor_x.SetValue=mubiao[5][0];
	 servo_motor_y.SetValue=mubiao[5][1];
   TIM_SetCompare1(TIM14,1280);//y��
   TIM_SetCompare1(TIM12,	1100);//x��  

}


void mode_five_three(void)
{
   servo_motor_x.Kp=2;//2
	servo_motor_x.Ki=0.02;
	servo_motor_x.Kd=40;//30
	servo_motor_x.SumError_limit=2000;
	servo_motor_x.flag1=1;
	
	
	servo_motor_y.Kp=2;
	servo_motor_y.Ki=0.02;
	servo_motor_y.Kd=40;
	servo_motor_y.SumError_limit=2000;
	servo_motor_y.flag1=1;
	servo_motor_x.SetValue=mubiao[4][0];
	servo_motor_y.SetValue=mubiao[4][1];
	
   TIM_SetCompare1(TIM14,1300);//y��
   TIM_SetCompare1(TIM12,960);//x�� 

}








