#ifndef __SERVO_MOTOR_PID_H
#define __SERVO_MOTOR_PID_H	
#include "sys.h"


#define servo_middle_X 1000  //�����ֵX
#define servo_middle_Y 1000  //�����ֵY

//int jiedian[9][2];

typedef struct
{
  float Kp;
  float Ki;
  float Kd;
  float Error;
	u8    flag1;
	u8    flag2;
	u8    flag3;
	u8    flag4;
	u8    flag5;
	u8    zhixing1;
	u8    zhixing2;
	u8    zhixing3;
	u8    zhixing4;
	u8    zhixing5;
	int   servo_middle;
	int   SumError;
	int   SumError_limit;
  int   SetValue;
  int   BackValue;
  int   LastError;
  int   PreError;
  int   PWMOut;
} Servo_motor;


void servo_motor_Init(void);
int  Servo_motor_Control_X(Servo_motor *V);
int  Servo_motor_Control_Y(Servo_motor *V);
void mode_zero(void);
void mode_one(void);
void mode_two(void);
void mode_two_twoo(void);
void mode_two_test(void);
void mode_three(void);
void mode_four(void);
void mode_five(void);
void mode_five_one(void);
void mode_five_two(void);
void mode_five_three(void);









#endif



