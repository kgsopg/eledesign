#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "key.h"
#include "lcd.h"
#include "usmart.h"  
#include "usart2.h"  
#include "timer.h" 
#include "ov2640.h" 
#include "dcmi.h" 
#include "pwm.h"
#include "servo_motor_pid.h"

 Servo_motor servo_motor_x;
 Servo_motor servo_motor_y;
u16 picture_buf[200][200];
u16 PWM_X,PWM_Y;
u16 x,y,last_x,last_y;
u16 PID_P=10      ;
float PID_D=0.5;

int fflag=0;

u8 mubiao[9][2]={{166,155},{98,160},{31,160},
                  {167,88},{96,93},{25,94},
                  {166,17},{95,19},{26,23},};



void rgb565_test(void)
{ 
	u16 i,j;
	u8 Gray;
	
	OV2640_SET_FPS(0x01);//FPS=30/(clkrc+1)
	OV2640_RGB565_Mode();	
	My_DCMI_Init();			
	DCMI_DMA_Init((u32)&picture_buf,sizeof(picture_buf)/4,DMA_MemoryDataSize_HalfWord,DMA_MemoryInc_Enable);
//	DCMI_DMA_Init((u32)&LCD->LCD_RAM,1,DMA_MemoryDataSize_HalfWord,DMA_MemoryInc_Disable);//DCMI DMA���� 
//	OV2640_Window_Set(0,0,1600,1200);
//	OV2640_ImageSize_Set(800,600);
//	OV2640_ImageWin_Set((800-lcddev.width)/2,(600-lcddev.height)/2,lcddev.width,lcddev.height);//1:1��ʵ�ߴ�	
// 	OV2640_OutSize_Set(lcddev.width,lcddev.height);
	OV2640_ImageWin_Set(100,0,600,600);//800 600 -> 600 600 
	OV2640_OutSize_Set(200,200);	
	DCMI_Start(); 		//��������
	while(1)
	{
		LCD_DrawRectangle(140,300,340,500);	
		LCD_DrawRectangle(139,299,341,501);	
		LCD_SetCursor(140,300);  
		LCD_WriteRAM_Prepare();		
		for(i=0;i<200;i++)
		{
			for(j=0;j<200;j++)
			{    
//				Gray =(((picture_buf[i][j]>>(8+3))<<11)|((abcd[i][j]>>(8+2))<<5)|((abcd[i][j]>>(8+3))<<0));
				Gray=(u8)(picture_buf[i][j]&0x00ff);	
				//i��������   j��������  j��ʼ
				if((i<3)||(i>195)||(j<3)||(j>195) )//(i<3)||(i>180)||(j<1)||(j>190)
				{
					Gray=BLACK;
					
				}
				if(Gray>200)
				{
					LCD->LCD_RAM=WHITE;
					x=j-2;y=i-3;
//					i=200;
//					break;					
				}
				else
				{
//					x=servo_motor_x.BackValue;
//		      y=servo_motor_y.BackValue;
					LCD->LCD_RAM=BLACK;
				}
			}		
		}
		servo_motor_x.BackValue=x;
		servo_motor_y.BackValue=y;
//		printf("%d    %d\r\n",x,y);
		LCD_Fast_DrawPoint(140+x-1,300+y,RED);
		LCD_Fast_DrawPoint(140+x,300+y-1,RED);
		LCD_Fast_DrawPoint(140+x,300+y,RED);
		LCD_Fast_DrawPoint(140+x+1,300+y,RED);
		LCD_Fast_DrawPoint(140+x,300+y+1,RED);
		
		x=0;
		y=0;
		if (servo_motor_y.flag2==60)
  {
    mode_two_twoo( );

  }
	if(servo_motor_y.flag5==60)
	{
	servo_motor_x.SetValue=mubiao[4][0];
	servo_motor_y.SetValue=mubiao[4][1];
	
//	 mode_five_one( );
	}

	
	
	
//		if(servo_motor_y.flag2>120)
//		{
//		   TIM_SetCompare1(TIM14,1000);//y��
//       TIM_SetCompare1(TIM12,	1000);//x��  
//		
//		}
		//mode_two_test( );
		
	}    
} 
	u16 x_pwm=1350;
	u16 y_pwm=1350;
int main(void)
{ 
	
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	delay_init(168);  
	uart_init(115200);		
	usart2_init(42,115200);		
	LED_Init();		
	KEY_Init( );
	TIM14_PWM_Init(20000-1,84-1);	//  600    -     2300     500    2400
 	LCD_Init();				
	POINT_COLOR=RED;
	if(lcddev.height>600)
	{
		lcddev.height=600;		//SVGAģʽ,���벻�ܴ���600.
		LCD_Set_Window(140,300,200,200);
	}

  servo_motor_Init( );	
//	mode_zero();
	 //  mode_one();
   // mode_two();
	// mode_three( );
 // mode_four( );
	//mode_five( );
  // 	mode_five( );
  //mode_five_one( );
	//mode_five_two( );
	// mode_four( );
  TIM3_Int_Init(100-1,8400-1);//10Khz����,1�����ж�һ��	 
//	TIM5_Int_Init(100-1,8400-1);//10Khz����,1�����ж�һ��	 
	while(OV2640_Init()){}
	TIM_SetCompare1(TIM14, 1160 );//y��   1160    ���  1360   gao  960
	TIM_SetCompare1(TIM12,1100);//x��   1100              980    1300
//
		
	 
	  while(!fflag);
		while(1)
		{
		rgb565_test();
		
		}
		

}


//		TIM3->CCR1=1200;//��С ��� 950   ���  1200   ��ֵ1060
//	  TIM3->CCR2=1100;//���� ��� 1350  ���  1100   ��ֵ1250

u8 key=0;
void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET) //����ж�
	{	
		key=KEY_Scan(0);
		switch(key)
			{		
					case KEY0_PRES:mode_zero(),fflag=1;break;
				  case KEY1_PRES:mode_one(),fflag=1;break;
				  case KEY2_PRES:mode_two(),fflag=1;break;
					case WKUP_PRES:mode_three( ),fflag=1;break;
				  case WKUP_PRES1:mode_five( ),fflag=1;break;
			}
//		printf("%d    %d\r\t",servo_motor_x.BackValue,servo_motor_y.BackValue);
	
	//printf("%d   %d\r\n",servo_motor_x.LastError,servo_motor_y.LastError);
	}
   TIM_ClearITPendingBit(TIM3,TIM_IT_Update);  //����жϱ�־λ
//	TIM_ITConfig(TIM3,TIM_IT_Update,DISABLE); //������ʱ��3�����ж�
//	TIM_Cmd(TIM3,DISABLE);
}



